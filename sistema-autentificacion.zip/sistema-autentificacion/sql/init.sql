CREATE DATABASE IF NOT EXISTS auth_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE auth_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- Inserta un usuario de prueba (contraseña “secret” hashed):
INSERT INTO users (username, password)
VALUES ('alice',  '$2y$10$E/.ihoGxP6GziQh9LRKE3uW7QvE7G1fz6GIwniVgO/S2c9hRInWGe');
