# Sistema de Autenticación con PHP + MySQL

## Descripción
Este mini-proyecto implementa un sistema de login/logout usando PHP, sesiones y MySQL. Incluye:

- Registro de sesión en PHP
- Verificación de usuario/contraseña
- Página protegida (`dashboard.php`)
- Logout

## Requisitos
- XAMPP (Apache + MySQL)
- PHP 7.4+ / 8.x
- Navegador web

## Instalación y prueba

1. Copiar esta carpeta dentro de `C:\xampp\htdocs\` (Windows) o `~/xampp/htdocs/` (Linux/Mac).
2. Iniciar Apache y MySQL desde el XAMPP Control Panel.
3. En phpMyAdmin (`http://localhost/phpmyadmin`), ir a **Importar** y cargar `sql/init.sql`.
4. Editar `config/config.php` si cambiaste usuario/clave de MySQL.  
   Por defecto está:
   ```php
   define('DB_USER', 'root');
   define('DB_PASS', '');
