<?php
require __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->execute([$user]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && password_verify($pass, $row['password'])) {
        // Credenciales correctas: guardamos datos en la sesión
        $_SESSION['user_id']   = $row['id'];
        $_SESSION['username']  = $user;
        header('Location: dashboard.php');
        exit;
    } else {
        echo "Usuario o contraseña incorrectos.";
    }
}
