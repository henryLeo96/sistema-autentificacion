<?php
require __DIR__ . '/../config/config.php';

// Si no hay sesión iniciada, redirigir al login
if (empty($_SESSION['user_id'])) {
    header('Location: ../public/index.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Dashboard</title></head>
<body>
  <h2>Bienvenido, <?= htmlspecialchars($_SESSION['username']) ?>!</h2>
  <p>Esta es tu área segura.</p>
  <a href="../public/logout.php">Cerrar sesión</a>
</body>
</html>
